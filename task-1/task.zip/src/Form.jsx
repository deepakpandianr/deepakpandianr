import React from "react";

const Form = () => {
    return (
        <div className='add-player-form'>
            <form>
                <input type='text' value='' />
                <input type='submit' value='Add Player' />
            </form>
        </div>
    );
};

export default Form;