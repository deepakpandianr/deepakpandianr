import React from "react";

const Header = () => {
    return (
        <div className="header">
            <table className="stats">
                <tbody>
                    <tr>
                        <td>Players:</td>
                        <td>3</td>
                    </tr>
                    <tr>
                        <td>Total Points:</td>
                        <td>76</td>
                    </tr>
                </tbody>
            </table>
            <h1>ScoreCard</h1>
            
        </div>
    );
}

export default Header;